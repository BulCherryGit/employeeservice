// build.js

const esbuild = require('esbuild');
const path = require('path');

esbuild.build({
  entryPoints: ['./src/index.ts'],
  bundle: true,
  outfile: './dist/index.js',
  platform: 'node',
  target: 'node22', // Target Node.js 14 runtime
  external: ['aws-sdk'], // Exclude AWS SDK from being bundled as it is included in Lambda runtime
}).catch(() => process.exit(1));
