import { zodvalidatePayload } from './zodvalidation';

const jsonPayload = {
    header: {
      entityPrimaryKey: "13223434",
      eventID: "434324",
      schemaVersion: 1
    },
    marketData: {
      id: "12323323",
      symbol: "BSEzz",
      lowPrice: 324.23,
      lastPrice: 324.23,
      date: 1709870400000 // Example UTC timestamp
    }
  };
  

console.log("Test>>>>> ");

// Validate the payload with async operations

zodvalidatePayload(jsonPayload).then((result) => {
  if (!result.success) {
    console.error("Validation failed:", result.errors);
  } else {
    console.log("Validation successful:", result.data);
  }
});
