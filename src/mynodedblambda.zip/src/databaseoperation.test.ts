// validateAndInsert.test.ts
import { validateAndInsert } from "./databaseop";
import { validatePayload } from "./validation";
import { convertToAEDT } from "./utils";
import db from "./db";

jest.mock("./validation");
jest.mock("./utils", () => ({ convertToAEDT: jest.fn() }));
jest.mock("./db", () => ({ oneOrNone: jest.fn(), none: jest.fn() }));

describe("validateAndInsert", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should return failure if validation fails and log error", async () => {
    (validatePayload as jest.Mock).mockResolvedValue({
      success: false,
      errors: "Validation error"
    });

    const result = await validateAndInsert({ marketData: {} } as any);
    expect(result).toEqual({ success: false, errors: "Validation error" });
  });

  
  it("should return failure if instrument is not found", async () => {
    (validatePayload as jest.Mock).mockResolvedValue({ success: true, data: {} });
    (convertToAEDT as jest.Mock).mockReturnValue(1700000000);
    (db.oneOrNone as jest.Mock).mockResolvedValue(null);

    const result = await validateAndInsert({ marketData: { symbol: "AAPL" } } as any);

    console.log("The result ---->>> "+result.success);
    expect(result.success).toBe(false);
  });

 
  it("should insert data successfully", async () => {
    (validatePayload as jest.Mock).mockResolvedValue({ success: true, data: {} });
    (convertToAEDT as jest.Mock).mockReturnValue(1700000000);
    (db.oneOrNone as jest.Mock).mockResolvedValue({ instrument_code: "INST123" });
    (db.none as jest.Mock).mockResolvedValue(undefined);

    const payload = {
      marketData: {
        segmentcode: "EQ",
        symbol: "AAPL",
        lowPrice: 150,
        tradedate: 1700000000
      }
    } as any;

    const result = await validateAndInsert(payload);
    expect(result).toEqual({ success: true, message: "Data inserted successfully" });
    expect(db.none).toHaveBeenCalled();
  });

  it("should return failure if database insertion fails", async () => {
    (validatePayload as jest.Mock).mockResolvedValue({ success: true, data: {} });
    (convertToAEDT as jest.Mock).mockReturnValue(1700000000);
    (db.oneOrNone as jest.Mock).mockResolvedValue({ instrument_code: "INST123" });
    (db.none as jest.Mock).mockRejectedValue(new Error("DB Insert Error"));

    const result = await validateAndInsert({ marketData: { symbol: "AAPL" } } as any);
    expect(result).toEqual({ success: false, errors: new Error("DB Insert Error") });
  });
  
 
});