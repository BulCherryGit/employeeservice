import { EventBridge } from 'aws-sdk';

const eventBridge = new EventBridge();

export const handler = async (event: any) => {
  try {
    const eventDetail = {
      source: 'custom.source',
      detailType: 'My Custom Event',
      detail: JSON.stringify({ message: 'Hello from EventBridge!' }),
      eventBusName: 'kish-event-but',  // Update with your EventBus name
    };

    const params = {
      Entries: [
        {
          Source: eventDetail.source,
          DetailType: eventDetail.detailType,
          Detail: eventDetail.detail,
          EventBusName: eventDetail.eventBusName,
        },
      ],
    };

    const result = await eventBridge.putEvents(params).promise();

    console.log('Event published successfully:', result);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Event published', result }),
    };
  } catch (error) {
    console.error('Error publishing event:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error publishing event', error }),
    };
  }
};
