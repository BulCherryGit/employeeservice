import { fromUnixTime, format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';

// Function to convert UTC timestamp (long) to AEDT format
export function convertToAEDT(utcTimestamp: number): Date | null {
  try {
    if (!Number.isInteger(utcTimestamp) || utcTimestamp < 0) {
      throw new Error("Invalid timestamp format");
    }

    const timeZone = 'Australia/Sydney'; // AEDT timezone
    const dateObject = fromUnixTime(utcTimestamp / 1000); // Convert to Date object
    const aedtDate = toZonedTime(dateObject, timeZone);

    //let convertedDate = format(aedtDate, 'yyyy-MM-dd HH:mm:ssXXX'); // Proper AEDT date string

   // console.log("Converted Date --->>>> "+convertedDate);
    return aedtDate;
  } catch (error) {
    console.error("Error converting UTC timestamp to AEDT:", error);
    return null; // Indicator for an invalid timestamp
  }
}

