import { z } from "zod";

// Header schema (optional)
export const headerSchema = z.object({
  entityPrimaryKey: z.string().optional(),
  eventID: z.string().optional(),
  schemaVersion: z.number().optional(),
}).optional();

// MarketData schema
export const marketDataSchema = z.object({
  id: z.string().min(1, "Id is required"),
  symbol: z.string().min(1, "Symbol is required"),
  lowPrice: z.number().int("lowPrice must be an integer").nonnegative("lowPrice must be positive").optional(),
  lastPrice: z.number().int("lastPrice must be an integer").nonnegative("lastPrice must be positive").optional(),
  highPrice: z.number().int("highPrice must be an integer").nonnegative("highPrice must be positive").optional(),
  date: z.number({
    required_error: "Date is required",
    invalid_type_error: "Date must be a number",
  }).int("Date must be an integer").min(0, "Date must be positive"),
}).superRefine((data, ctx) => {
  // Ensure at least one price field is present
  if (data.lowPrice === undefined && data.lastPrice === undefined && data.highPrice === undefined) {
    
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "At least one of lowPrice, lastPrice, or highPrice must be present",
      path: ["lowPrice|lastPrice|highPrice"], // Attach the error message to one of the missing fields
    });
  }
});

// Full Payload Schema
export const payloadSchema = z.object({
  header: headerSchema,
  marketData: marketDataSchema,
});


// Async function to validate payload with additional checks
export async function zodvalidatePayload(payload: unknown) {
  const parsed = payloadSchema.safeParse(payload);

    
  if (!parsed.success) {
    const errorMessage = parsed.error.issues
    .map(issue => `Path: ${issue.path.join(".")}, Message: ${issue.message}`)
    .join(" | "); // Separating messages with " | "

  console.log("Validation Issues --->>>", errorMessage);
  return { success: false, errors: errorMessage };

   // return { success: false, errors: parsed.error.errors[0].message };
  }
  else 
  return { success: true, data: parsed.data };
}
