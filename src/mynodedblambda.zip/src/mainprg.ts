import { validateAndInsert } from './databaseop';
import { Payload } from './models';
import { validatePayload } from './validation';



const samplePayload: Payload = {
  header: {
    entityPrimaryKey: "12345",
    eventID: "abc123",
    schemaVersion: 1,
  },
  marketData: {
    segmentcode: "EQ",
    symbol: "BSE",
    instrumentcode: "AA",
    lowPrice: -334,
    
    tradedate: 17272000000,  // UTC timestamp (long)
  },
};

console.log("Test the database operation");

// Validate the payload with async operations

validateAndInsert(samplePayload).then((result) => {
  console.log(result);
  if (!result.success) {
    console.error("Validation failed:", result.errors);
  } else {
    console.log("Validation successful:", result.success);
  }
});



