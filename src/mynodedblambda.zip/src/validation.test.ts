import { validatePayload } from "./validation";
import db from "./db";
import { convertToAEDT } from "./utils";
import { Payload } from "./models";

jest.mock("./db");
jest.mock("./utils", () => ({
  convertToAEDT: jest.fn()
}));

describe("validatePayload", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should return success when payload is valid", async () => {
    const mockPayload: Payload = {
      header: { eventID: "12345" },
      marketData: {
        segmentcode: "EQ",
        symbol: "AAPL",
        lastPrice: 150,
        tradedate: 1700000000
      }
    };

    (convertToAEDT as jest.Mock).mockReturnValue(1700000000);
    (db.oneOrNone as jest.Mock).mockResolvedValue({});

    const result = await validatePayload(mockPayload);
    expect(result).toEqual({ success: true, data: mockPayload });
  });

  it("should fail if no price fields are provided", async () => {
    const mockPayload: Payload = {
      header: { eventID: "12345" },
      marketData: {
        segmentcode: "EQ",
        symbol: "AAPL",
        tradedate: 1700000000
      }
    };

    const result = await validatePayload(mockPayload);
    expect(result.success).toBe(false);
    expect(result.errors).toContain("At least one of lowPrice, lastPrice, or highPrice must be present");
  });

  it("should fail if trade date is invalid", async () => {
    const mockPayload: Payload = {
      header: { eventID: "12345" },
      marketData: {
        segmentcode: "EQ",
        symbol: "AAPL",
        lastPrice: 150,
        tradedate: 1700000000
      }
    };

    (convertToAEDT as jest.Mock).mockReturnValue(null);

    const result = await validatePayload(mockPayload);
    expect(result.success).toBe(false);
    expect(result.errors).toHaveProperty("tradedate", "Invalid Trade date");
  });

  it("should fail if symbol does not exist", async () => {
    const mockPayload: Payload = {
      header: { eventID: "12345" },
      marketData: {
        segmentcode: "EQ",
        symbol: "INVALID",
        lastPrice: 150,
        tradedate: 1700000000
      }
    };

    (convertToAEDT as jest.Mock).mockReturnValue(1700000000);
    (db.oneOrNone as jest.Mock).mockResolvedValue(null);

    const result = await validatePayload(mockPayload);
    expect(result.success).toBe(false);
    expect(result.errors).toHaveProperty("symbol", "Symbol does not exist in Reference_data table");
  });
});
