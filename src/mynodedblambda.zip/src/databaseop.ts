import { Payload } from "./models";
import db from "./db";
import { validatePayload } from "./validation";
import { convertToAEDT } from "./utils";
import { insertAuditData } from "./insertAuditData";

/*
const insertMarketDataPrice = async (marketSegmentCode: string, commodityCode: string) => {
  try {
    // Step 1: Fetch instrument_code based on commodity_code
    const instrument = await db.oneOrNone(
      `SELECT instrument_code FROM instrument WHERE commodity_code = $1`,
      [commodityCode]
    );

    if (!instrument) {
      console.error(`No instrument found for commodity_code: ${commodityCode}`);
      return;
    }

    // Step 2: Insert into market_data_price using fetched instrument_code
    await db.none(
      `INSERT INTO market_data_price (market_segmentcode, commodity_code, instrustment_code)
       VALUES ( $2, $3, $4)`,
      [marketSegmentCode, commodityCode, instrument.instrument_code]
    );

    console.log(`Inserted successfully for commodity_code: ${commodityCode}`);
  } catch (error) {
    console.error('Error inserting market_data_price:', error);
  }
};
*/


// Function to validate data and insert into TransactData or AuditHistory
export async function validateAndInsert(data: Payload) {
    const validationResult = await validatePayload(data);
    if (!validationResult.success) {
        const errorDetails = JSON.stringify(validationResult.errors);
        console.log("Error details --> "+errorDetails);
        insertAuditData(errorDetails);
        // await db.none(
        //     `INSERT INTO AuditHistory (transactData, errorDetails) VALUES ($1, $2)`,
        //     [JSON.stringify(data.transactData), errorDetails]
        // );
        return { success: false, errors: validationResult.errors };
    }
    
    const  marketData  = data.marketData;
    let tradetimestamp = marketData.tradedate
    const tradeDateAEDT = convertToAEDT(tradetimestamp);

    console.log('tradeDateAEDT --> '+tradeDateAEDT);
    
    
    try {


        const instrument = await db.oneOrNone(`SELECT instrument_code FROM instrument WHERE commodity_code = $1`, [marketData.symbol]);
        console.log("instroument code is "+instrument.instrument_code);

        if (!instrument) {
            console.error(`No instrument found for commodity_code: ${marketData.symbol}`);
            insertAuditData(data);
            return { success: false, errors: 'No instrument code found'} ;
          }

      

        const insertQuery = `
        INSERT INTO market_data_price (
          market_segmentcode, 
          commodity_code, 
          instrument_code, 
          low_price, 
          last_price, 
          high_price, 
          trade_date
        ) 
        VALUES (
          $(segmentCode), 
          $(symbol), 
          $(instrumentCode), 
          $(lowPrice), 
          $(lastPrice), 
          $(highPrice), 
          $(tradeDate)
        )
      `;

      const values = {
        segmentCode: marketData?.segmentcode,
        symbol: marketData?.symbol,
        instrumentCode: instrument.instrument_code,
        lowPrice: marketData?.lowPrice ?? null,  // Handle missing lowPrice
        lastPrice: marketData?.lastPrice ?? null,  // Handle missing lastPrice
        highPrice: marketData?.highPrice ?? null,  // Handle missing highPrice
        tradeDate: tradeDateAEDT
      };

        // Insert into TransactData table
        await db.none(insertQuery, values);
        
        
        return { success: true, message: 'Data inserted successfully' };
    } catch (error) {
        console.log(" Error  -->>> "+error);
        return { success: false, errors: error };
    }


    


}

// Example Usage
//insertMarketDataPrice('SG', 'CR'); // Replace 'SG' and 'CR' with actual values
