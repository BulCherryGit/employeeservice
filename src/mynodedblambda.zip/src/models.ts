export interface Header {
    entityPrimaryKey?: string;
    eventID?: string;
    schemaVersion?: number;
  }
  
  export interface MarketData {
    segmentcode: string;
    symbol: string;
    instrumentcode?: string;
    lowPrice?: number;
    lastPrice?: number;
    highPrice?: number;
    tradedate: number;  // UTC timestamp (long)
  }
  
  export interface Payload {
    header?: Header;  // Optional
    marketData: MarketData; // Required
  }
  