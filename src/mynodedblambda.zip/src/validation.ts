import { z } from 'zod';
import db from './db';
import { Payload } from './models';
import { convertToAEDT } from './utils';

// Header schema (optional)
export const headerSchema = z.object({
  entityPrimaryKey: z.string().optional(),
  eventID: z.string().optional(),
  schemaVersion: z.number().optional(),
}).optional();


// MarketData schema
export const marketDataSchema = z.object({
  segmentcode: z.string().nonempty("segmentcode is required"),
  symbol: z.string().nonempty("Symbol is required"),
  lowPrice: z.number().optional(),
  lastPrice: z.number().optional(),
  highPrice: z.number().optional(),
  tradedate: z.number().int("Date must be an integer").nonnegative("Date must be positive"),
}).refine((data) => data.lowPrice !== undefined || data.lastPrice !== undefined || data.highPrice !== undefined, {
  message: "At least one of lowPrice, lastPrice, or highPrice must be present",
  path: ["lowPrice", "lastPrice", "highPrice"],
});

// Full payload schema
export const payloadSchema = z.object({
  header: headerSchema,
  marketData: marketDataSchema,
});

// Function to check if symbol exists in Reference_data table
async function isSymbolValid(symbol: string): Promise<boolean> {
  const result = await db.oneOrNone('SELECT 1 FROM Reference_data WHERE code = $1', [symbol]);
  return !!result; // Returns true if symbol exists
}

// Async function to validate payload with additional checks
export async function validatePayload(payload: Payload) {
  const parsed = payloadSchema.safeParse(payload);

  console.log("  Parsed Result --->>> "+parsed)
  
  if (!parsed.success) {
    const errorMessage = parsed.error.issues
    .map(issue => `Path: ${issue.path.join(".")}, Message: ${issue.message}`)
    .join(" | "); // Separating messages with " | "

  console.log("Validation Issues --->>>", errorMessage);
  return { success: false, errors: errorMessage };

    
//    return { success: false, errors: parsed.error.format() };
  }

  const { marketData } = parsed.data;

  const tradeDateAEDT = convertToAEDT(marketData.tradedate);

  if (tradeDateAEDT === null) {
    console.log('Error converting trade_date to AEDT');
    return { success: false, errors: { tradedate: "Invalid Trade date" } };
  }

 

  // Check if symbol exists in database
  const symbolExists = await isSymbolValid(marketData.symbol);
  if (!symbolExists) {
    return { success: false, errors: { symbol: "Symbol does not exist in Reference_data table" } };
  }

  return { success: true, data: parsed.data };
}
