export type User2 = {
    name: string;
    age: number;
    mobileNumber?: string;
    homePhoneNumber?: string;
    courtesyTitle: 'Mrs' | 'Mr' | 'Miss';
  };
  
  export type ValidationError = {
    field: string;
    message: string;
  };
  
  export type ValidationResult = {
    summary: string;
    errorDetails: ValidationError[];
  };
  
  export const validateUserPayload2 = (user: User2): ValidationResult => {
    const errorDetails: ValidationError[] = [];
  
    // 1. Name is mandatory
    if (!user.name) {
      errorDetails.push({
        field: 'name',
        message: 'Name is mandatory.',
      });
    }
  
    // 2. Age is mandatory and should not be negative
    if (user.age === undefined || user.age < 0) {
      errorDetails.push({
        field: 'age',
        message: 'Age is mandatory and cannot be negative.',
      });
    }
  
    // 3. At least one of mobileNumber or homePhoneNumber is required
    if (!user.mobileNumber && !user.homePhoneNumber) {
      errorDetails.push({
        field: 'mobileNumber or homePhoneNumber',
        message: 'At least one of mobileNumber or homePhoneNumber is required.',
      });
    }
  
    // 4. Courtesy Title must be one of 'Mrs', 'Mr', or 'Miss'
    if (!['Mrs', 'Mr', 'Miss'].includes(user.courtesyTitle)) {
      errorDetails.push({
        field: 'courtesyTitle',
        message: "Courtesy Title must be 'Mrs', 'Mr', or 'Miss'.",
      });
    }
  
    // If there are any errors, return the result with summary and details, otherwise return an empty result
    if (errorDetails.length > 0) {
      return {
        summary: 'Validation failed for payload',
        errorDetails,
      };
    } else {
      return {
        summary: 'Validation passed for payload',
        errorDetails: [],
      };
    }
  };
  