import { User, validateUserPayload } from './uservalidator';


describe("User Payload Validation", () => {

  it("should pass for a valid user payload", () => {
    const validUser: User = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(validUser);
    expect(errors).toHaveLength(0); // No validation errors
  });

  it("should fail when name is missing", () => {
    const invalidUser: any = {
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(invalidUser);
    expect(errors).toContain("Name is mandatory.");
  });

  it("should fail when age is missing", () => {
    const invalidUser: any = {
      name: "John Doe",
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(invalidUser);
    expect(errors).toContain("Age is mandatory and cannot be negative.");
  });

  it("should fail when age is negative", () => {
    const invalidUser:any = {
      name: "John Doe",
      age: -1,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(invalidUser);
    expect(errors).toContain("Age is mandatory and cannot be negative.");
  });

  it("should fail when neither mobileNumber nor homePhoneNumber is provided", () => {
    const invalidUser: any = {
      name: "John Doe",
      age: 25,
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(invalidUser);
    expect(errors).toContain("At least one of mobileNumber or homePhoneNumber is required.");
  });

  it("should pass when both mobileNumber and homePhoneNumber are provided", () => {
    const validUser :any = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      homePhoneNumber: "0987654321",
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(validUser);
    expect(errors).toHaveLength(0); // No validation errors
  });

  it("should fail when courtesyTitle is invalid", () => {
    const invalidUser: any = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Dr"
    };
    const errors = validateUserPayload(invalidUser);
    expect(errors).toContain("Courtesy Title must be 'Mrs', 'Mr', or 'Miss'.");
  });

  it("should pass when courtesyTitle is 'Mrs'", () => {
    const validUser :any = {
      name: "Jane Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mrs"
    };
    const errors = validateUserPayload(validUser);
    expect(errors).toHaveLength(0);
  });

  it("should pass when courtesyTitle is 'Mr'", () => {
    const validUser: any = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(validUser);
    expect(errors).toHaveLength(0);
  });

  it("should pass when courtesyTitle is 'Miss'", () => {
    const validUser: any = {
      name: "Miss Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Miss"
    };
    const errors = validateUserPayload(validUser);
    expect(errors).toHaveLength(0);
  });

});
