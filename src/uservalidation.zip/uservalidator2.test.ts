import { User2, validateUserPayload2 } from "./uservalidator2";

describe("User Payload Validation", () => {

  it("should return validation error details for an invalid user payload", () => {
    const invalidUser: any = {
      name: "",
      age: -1,
      courtesyTitle: "Dr"
    };
    const validationResult = validateUserPayload2(invalidUser);

    // Check the summary message
    expect(validationResult.summary).toBe("Validation failed for payload");

    // Check that we have exactly 4 error details
    expect(validationResult.errorDetails).toHaveLength(4);

    // Check each error detail
    expect(validationResult.errorDetails).toContainEqual({
      field: "name",
      message: "Name is mandatory."
    });

    expect(validationResult.errorDetails).toContainEqual({
      field: "age",
      message: "Age is mandatory and cannot be negative."
    });

    expect(validationResult.errorDetails).toContainEqual({
      field: "mobileNumber or homePhoneNumber",
      message: "At least one of mobileNumber or homePhoneNumber is required."
    });

    expect(validationResult.errorDetails).toContainEqual({
      field: "courtesyTitle",
      message: "Courtesy Title must be 'Mrs', 'Mr', or 'Miss'."
    });
  });

  it("should return validation success for a valid user payload", () => {
    const validUser: any = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const validationResult = validateUserPayload2(validUser);

    // Check the summary message
    expect(validationResult.summary).toBe("Validation passed for payload");

    // Ensure there are no error details
    expect(validationResult.errorDetails).toHaveLength(0);
  });

  it("should return an error when name is missing", () => {
    const invalidUser: any = {
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const validationResult = validateUserPayload2(invalidUser);

    expect(validationResult.summary).toBe("Validation failed for payload");
    expect(validationResult.errorDetails).toContainEqual({
      field: "name",
      message: "Name is mandatory."
    });
  });

  it("should return an error when age is negative", () => {
    const invalidUser: any = {
      name: "John Doe",
      age: -1,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const validationResult = validateUserPayload2(invalidUser);

    expect(validationResult.summary).toBe("Validation failed for payload");
    expect(validationResult.errorDetails).toContainEqual({
      field: "age",
      message: "Age is mandatory and cannot be negative."
    });
  });

  it("should return an error when neither mobileNumber nor homePhoneNumber is provided", () => {
    const invalidUser: any = {
      name: "John Doe",
      age: 25,
      courtesyTitle: "Mr"
    };
    const validationResult = validateUserPayload2(invalidUser);

    expect(validationResult.summary).toBe("Validation failed for payload");
    expect(validationResult.errorDetails).toContainEqual({
      field: "mobileNumber or homePhoneNumber",
      message: "At least one of mobileNumber or homePhoneNumber is required."
    });
  });

  it("should return validation success when both mobileNumber and homePhoneNumber are provided", () => {
    const validUser: any = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      homePhoneNumber: "0987654321",
      courtesyTitle: "Mr"
    };
    const validationResult = validateUserPayload2(validUser);

    expect(validationResult.summary).toBe("Validation passed for payload");
    expect(validationResult.errorDetails).toHaveLength(0);
  });

  it("should return an error when courtesyTitle is invalid", () => {
    const invalidUser: any = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Dr"
    };
    const validationResult = validateUserPayload2(invalidUser);

    expect(validationResult.summary).toBe("Validation failed for payload");
    expect(validationResult.errorDetails).toContainEqual({
      field: "courtesyTitle",
      message: "Courtesy Title must be 'Mrs', 'Mr', or 'Miss'."
    });
  });

  it("should return validation success when courtesyTitle is 'Mrs'", () => {
    const validUser: any = {
      name: "Jane Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mrs"
    };
    const validationResult = validateUserPayload2(validUser);

    expect(validationResult.summary).toBe("Validation passed for payload");
    expect(validationResult.errorDetails).toHaveLength(0);
  });

  it("should return validation success when courtesyTitle is 'Mr'", () => {
    const validUser: any = {
      name: "John Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Mr"
    };
    const validationResult = validateUserPayload2(validUser);

    expect(validationResult.summary).toBe("Validation passed for payload");
    expect(validationResult.errorDetails).toHaveLength(0);
  });

  it("should return validation success when courtesyTitle is 'Miss'", () => {
    const validUser: any = {
      name: "Miss Doe",
      age: 25,
      mobileNumber: "1234567890",
      courtesyTitle: "Miss"
    };
    const validationResult = validateUserPayload2(validUser);

    expect(validationResult.summary).toBe("Validation passed for payload");
    expect(validationResult.errorDetails).toHaveLength(0);
  });
});
