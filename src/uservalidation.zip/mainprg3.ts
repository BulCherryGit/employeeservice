import { validateUserPayload } from "./uservalidator";
import { validateUserPayload2 } from "./uservalidator2";

   const invalidUser: any = {
      
      
      courtesyTitle: "Mr"
    };
    const errors = validateUserPayload(invalidUser);

    console.log(errors);


    let result = validateUserPayload2(invalidUser);

    console.log(result);