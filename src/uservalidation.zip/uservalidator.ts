export type User = {
    name: string;
    age: number;
    mobileNumber?: string;
    homePhoneNumber?: string;
    courtesyTitle: 'Mrs' | 'Mr' | 'Miss';
  };
  
  export const validateUserPayload = (user: User): string[] => {
    const errors: string[] = [];
  
    // 1. Name is mandatory
    if (!user.name) {
      errors.push("Name is mandatory.");
    }
  
    // 2. Age is mandatory and should not be negative
    if (user.age === undefined || user.age < 0) {
      errors.push("Age is mandatory and cannot be negative.");
    }
  
    // 3. At least one of mobileNumber or homePhoneNumber is required
    if (!user.mobileNumber && !user.homePhoneNumber) {
      errors.push("At least one of mobileNumber or homePhoneNumber is required.");
    }
  
    // 4. Courtesy Title must be one of 'Mrs', 'Mr', or 'Miss'
    if (!['Mrs', 'Mr', 'Miss'].includes(user.courtesyTitle)) {
      errors.push("Courtesy Title must be 'Mrs', 'Mr', or 'Miss'.");
    }
  
    return errors;
  };
  