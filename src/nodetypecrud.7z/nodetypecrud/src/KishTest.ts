import { Note } from "./model/Note";
import { NoteRepo } from "./repository/NoteRepo";
import Database from "./config/database";



function databaseSync(): void {
    const db = new Database();
    db.sequelize?.sync();
  }

async function invokeCreateMethod() {

    databaseSync();
    const new_note = new Note();
    new_note.name = 'note12332';
    new_note.description = 'req.body.description23232';

    await new NoteRepo().save(new_note);
    console.log('Created ....');
}

invokeCreateMethod();