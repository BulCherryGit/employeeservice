interface IRouter {
     routes(): void
}

export default IRouter