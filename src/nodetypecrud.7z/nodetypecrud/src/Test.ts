import { z } from 'zod';

// Define a schema with an optional field and a default value
const schema = z.object({
  name: z.string(),
  age: z.number().optional(),
  country: z.string().default("Unknown"),
});

const data = { name: "Alice" };

const parsed = schema.parse(data);

console.log(parsed);
// Output: { name: 'Alice', country: 'Unknown' }




const schema1 = z.object({
  
        name: z
          .string()
          .min(1, { message: "Name must be greater than 1 characters!" }),
        description: z
          .string()
          .min(4, { message: "Descrition must be greater than 4 characters!" }),
   
  
  });
  

  const data1 = { name: "sfsd" , description:"sdfdsfdfdf"};

  const parsed1 = schema1.parse(data1)

  console.log(parsed1)