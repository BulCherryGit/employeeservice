import { fromUnixTime, format } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import pgPromise from 'pg-promise';

// Initialize PostgreSQL connection
const pgp = pgPromise();
const db = pgp({
  host: 'your-db-host',
  port: 5432,
  database: 'your-db-name',
  user: 'your-db-user',
  password: 'your-db-password',
});

// Function to convert UTC timestamp to AEDT and save to PostgreSQL
async function saveTimestampToDB_KK(utcTimestamp: number) {
  const timeZone = 'Australia/Sydney';

  // Convert timestamp (milliseconds) to Date object
  const utcDate = fromUnixTime(utcTimestamp / 1000);

  // Convert UTC to AEDT
  const aedtDate = toZonedTime(utcDate, timeZone);

  // Format the date for PostgreSQL (YYYY-MM-DD HH:mm:ss)
  const formattedDate = format(aedtDate, 'yyyy-MM-dd HH:mm:ss');

  // Insert into database
  await db.none('INSERT INTO your_table (aedt_timestamp) VALUES ($1)', [formattedDate]);

  console.log(`Saved AEDT Date: ${formattedDate}`);
}

// Example: Process a JSON payload
const jsonPayload = { timestamp: 1709870400000 }; // Example UTC timestamp in milliseconds
saveTimestampToDB_KK(jsonPayload.timestamp).catch(console.error);
