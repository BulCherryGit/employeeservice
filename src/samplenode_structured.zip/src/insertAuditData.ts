import db from "./db";
// Function to insert sample JSON payload into the audit_history table
export async function insertAuditData(payload:any) {
  try {
    // Prepare the data to be inserted
    const insertData = {
      auditData: payload, // JSON payload
      auditStatus: 'Success', // Example audit status
    };

    // Insert the data into the database
    const result = await db.none(`
      INSERT INTO audit_history (audit_data, audit_status)
      VALUES ($(auditData), $(auditStatus))
    `, insertData);

    console.log("Audit Data inserted successfully:", result);
  } catch (error) {
    console.error("Error inserting data into audit_history:", error);
  }
}
